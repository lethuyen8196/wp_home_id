<?php

require get_template_directory() . '/inc/init.php';
