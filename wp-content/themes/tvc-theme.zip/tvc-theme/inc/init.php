<?php
/*Custom Admin */
require_once dirname(__FILE__) . '/admin/customize-admin.php';
require_once dirname(__FILE__) . '/admin/admin-init.php';

require_once dirname(__FILE__) . '/functions/theme-setup.php';
require_once dirname(__FILE__) . '/functions/function-global.php';
// require_once dirname(__FILE__) . '/functions/database.php';

require_once dirname(__FILE__) . '/functions/ajax.php';
require_once dirname(__FILE__) . '/functions/post-type-project.php';
